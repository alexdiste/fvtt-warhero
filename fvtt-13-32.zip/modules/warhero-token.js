import { WarheroUtility } from "./warhero-utility.js";

/* -------------------------------------------- */
export class WarheroToken extends Token {
  
}
