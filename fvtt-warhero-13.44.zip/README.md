**WARHERO**

ENGLISH

The Warhero rulebook it belongs to Tanzini Francesco and can be found here https://www.warhero.it/.
It is under Creative Common non derivative work license https://creativecommons.org/licenses/by-nd/3.0/it/.
I had written permission from original author to create this game system for foundry virtual table top. Sme little changes has been done to better adapt rulebook to foundry but they are very limited and however original author grant me the permission to do that.

Icons coming from https://game-icons.net/ and they are covered from Creactive common license https://creativecommons.org/licenses/by/3.0/


ITALIAN

Il regolamento di warhero che può essere trovato al seguente link: https://www.warhero.it/ appartiene a Tanzini Francesco ed è coperto da licenza Creative Commons Attribuzione - Non opere derivate 3.0 Italia https://creativecommons.org/licenses/by-nd/3.0/it/.
Tuttavia l' autore originale mi ha dato il permesso scritto di creare il sistema di gioco di Warhero per il tool foundry virtual table top. Qualsiasi remix o modifica fatta si è resa necessaria per l' adattamento a foundry ma ho comunque il permesso per farle.

Le icone provengono invece da https://game-icons.net/ e sono coperte anche essere dalla licensa CC BY 3.0 https://creativecommons.org/licenses/by/3.0/
